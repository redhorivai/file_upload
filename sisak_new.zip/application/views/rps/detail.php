<div class="mb-3 d-flex justify-content-between">
    <div>&nbsp;</div>
    <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#modalAdd">
        <i class="ri-add-line"></i>&nbsp; Tambah Detail
    </button>
</div>

<!-- ========================================== MODAL ========================================== --->
<!-- ADD -->
<div class="modal fade" id="modalAdd" tabindex="-1" aria-labelledby="modalAddLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-dialog-scorllable modal-fullscreen">
        <div class="modal-content">
            <div class="modal-header">
                <h1 class="modal-title fs-5" id="modalAddLabel">Tambah RSP</h1>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <form id="frmAdd">
                    <div class="container">
                        <div class="mb-3">
                            <label class="fw-bold mb-2 d-block">Dibuat Oleh</label>
                            <select name="creator_id" id="creator_id" placeholder="Cari nama">
                                <option value="">- Pilih Dosen -</option>
                                <?php
                                    foreach($user as $index => $value) {
                                        echo "<option value='". $value->id ."'>". $value->name ."</option>";
                                    }
                                ?>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label class="fw-bold mb-2 d-block">Prodi</label>
                            <select name="prodi_id" id="prodi_id" placeholder="Cari prodi">
                                <option value="">- Pilih Prodi -</option>
                                <?php
                                    foreach($prodi as $index => $value) {
                                        echo "<option value='". $value->id ."'>". $value->nama ."</option>";
                                    }
                                ?>
                            </select>
                        </div>
                        <div class="mb-3 form-floating">
                            <input type="text" class="form-control" name="matkul" id="matkul" placeholder="-">
                            <label for="matkul">Matkul</label>
                        </div>
                        <div class="mb-3 form-floating">
                            <input type="text" class="form-control" name="kode_matkul" id="kode_matkul" placeholder="-">
                            <label for="kode_matkul">Kode Matkul</label>
                        </div>
                        <div class="mb-3 form-floating">
                            <input type="number" class="form-control" name="semester" id="semester" placeholder="-">
                            <label for="semester">Semester</label>
                        </div>
                        <div class="mb-3 form-floating">
                            <input type="number" class="form-control" name="sks" id="sks" placeholder="-">
                            <label for="sks">SKS</label>
                        </div>
                        <div class="mb-3 form-floating">
                            <input type="number" class="form-control" name="pertemuan" id="pertemuan" placeholder="-">
                            <label for="pertemuan">Pertemuan</label>
                        </div>
                        <div class="mb-3">
                            <label class="fw-bold mb-2 d-block">Dosen Lain</label>
                            <select name="dosen[]" id="dosen" placeholder="Cari dosen" multiple>
                                <option value="">- Pilih Dosen -</option>
                                <?php
                                    foreach($dosen as $index => $value) {
                                        echo "<option value='". $value->id ."'>". $value->user->name ."</option>";
                                    }
                                ?>
                            </select>
                        </div>
                        <div class="mb-3 form-floating">
                            <select type="text" class="form-select" name="publish" id="publish">
                                <option value="">- Pilih Status Publish -</option>
                                <option value="1">PUBLISH</option>
                                <option value="0">DRAFT</option>
                            </select>
                            <label for="">Status Publish</label>
                        </div>
                        <div class="mb-3 form-floating">
                            <select type="text" class="form-select" name="approved" id="approved">
                                <option value="">- Pilih Status -</option>
                                <option value="1">DISETUJUI</option>
                                <option value="0">BELUM DISETUJUI</option>
                            </select>
                            <label for="">Status</label>
                        </div>
                        <div class="mb-3">
                            <label class="fw-bold mb-2 d-block">Disetujui Oleh</label>
                            <select name="approved_by" id="approved_by" placeholder="Cari nama">
                                <option value="">- Pilih Approved By -</option>
                                <?php
                                    foreach($user as $index => $value) {
                                        echo "<option value='". $value->id ."'>". $value->name ."</option>";
                                    }
                                ?>
                            </select>
                        </div>
                        <button type="button" class="btn btn-primary" onclick="thisPage.addData()"><i class="ri-add-line"></i>&nbsp; Tambah</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<!-- EDIT -->
<div class="modal fade" id="modalEdit" tabindex="-1" aria-labelledby="modalEditLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-dialog-scorllable modal-fullscreen">
        <div class="modal-content">
            <div class="modal-header">
                <h1 class="modal-title fs-5" id="modalEditLabel">Edit RSP</h1>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <form id="frmEdit">
                    <input type="hidden" name="id" id="id">
                    <div class="container">
                        <div class="mb-3">
                            <label class="fw-bold mb-2 d-block">Dibuat Oleh</label>
                            <select name="creator_id" id="creator_id" placeholder="Cari nama">
                                <option value="">- Pilih Dosen -</option>
                                <?php
                                    foreach($user as $index => $value) {
                                        echo "<option value='". $value->id ."'>". $value->name ."</option>";
                                    }
                                ?>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label class="fw-bold mb-2 d-block">Prodi</label>
                            <select name="prodi_id" id="prodi_id" placeholder="Cari prodi">
                                <option value="">- Pilih Prodi -</option>
                                <?php
                                    foreach($prodi as $index => $value) {
                                        echo "<option value='". $value->id ."'>". $value->nama ."</option>";
                                    }
                                ?>
                            </select>
                        </div>
                        <div class="mb-3 form-floating">
                            <input type="text" class="form-control" name="matkul" id="matkul" placeholder="-">
                            <label for="matkul">Matkul</label>
                        </div>
                        <div class="mb-3 form-floating">
                            <input type="text" class="form-control" name="kode_matkul" id="kode_matkul" placeholder="-">
                            <label for="kode_matkul">Kode Matkul</label>
                        </div>
                        <div class="mb-3 form-floating">
                            <input type="number" class="form-control" name="semester" id="semester" placeholder="-">
                            <label for="semester">Semester</label>
                        </div>
                        <div class="mb-3 form-floating">
                            <input type="number" class="form-control" name="sks" id="sks" placeholder="-">
                            <label for="sks">SKS</label>
                        </div>
                        <div class="mb-3 form-floating">
                            <input type="number" class="form-control" name="pertemuan" id="pertemuan" placeholder="-">
                            <label for="pertemuan">Pertemuan</label>
                        </div>
                        <div class="mb-3">
                            <label class="fw-bold mb-2 d-block">Dosen Lain</label>
                            <select name="dosen[]" id="dosen" placeholder="Cari dosen" multiple>
                                <option value="">- Pilih Dosen -</option>
                                <?php
                                    foreach($dosen as $index => $value) {
                                        echo "<option value='". $value->id ."'>". $value->user->name ."</option>";
                                    }
                                ?>
                            </select>
                        </div>
                        <div class="mb-3 form-floating">
                            <select type="text" class="form-select" name="publish" id="publish">
                                <option value="">- Pilih Status Publish -</option>
                                <option value="1">PUBLISH</option>
                                <option value="0">DRAFT</option>
                            </select>
                            <label for="">Status Publish</label>
                        </div>
                        <div class="mb-3 form-floating">
                            <select type="text" class="form-select" name="approved" id="approved">
                                <option value="">- Pilih Status -</option>
                                <option value="1">DISETUJUI</option>
                                <option value="0">BELUM DISETUJUI</option>
                            </select>
                            <label for="">Status</label>
                        </div>
                        <div class="mb-3">
                            <label class="fw-bold mb-2 d-block">Disetujui Oleh</label>
                            <select name="approved_by" id="approved_by" placeholder="Cari nama">
                                <option value="">- Pilih Approved By -</option>
                                <?php
                                    foreach($user as $index => $value) {
                                        echo "<option value='". $value->id ."'>". $value->name ."</option>";
                                    }
                                ?>
                            </select>
                        </div>
                        <button type="button" class="btn btn-primary" onclick="thisPage.updateData()"><i class="ri-save-line"></i>&nbsp; Simpan</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<!-- ========================================== MODAL ========================================== --->

<div class="table-responsive">
    <table class="table table-striped table-bordered" id="datatable">
        <thead>
            <tr>
                <th class="bg-dark text-white">Matkul</th>
                <th class="bg-dark text-white">Kode</th>
                <th class="bg-dark text-white">Prodi</th>
                <th class="bg-dark text-white">Status</th>
                <th class="bg-dark text-white">Publish</th>
                <th class="bg-dark text-white">Created At</th>
                <th class="bg-dark text-white">Updated At</th>
                <th class="bg-dark text-white">#</th>
            </tr>
        </thead>
        <tbody></tbody>
    </table>
</div>

<script>
    var userSelect;
    var prodiSelect;
    var approvedBySelect;
    var dosenSelect;

    $(document).ready(() => {
        thisPage.loadData();

        userSelect = new TomSelect('#modalAdd #creator_id', { allowEmptyOption: true });
        prodiSelect = new TomSelect('#modalAdd #prodi_id', { allowEmptyOption: true });
        approvedBySelect = new TomSelect('#modalAdd #approved_by', { allowEmptyOption: true });
        dosenSelect = new TomSelect('#modalAdd #dosen', { allowEmptyOption: false });
        userSelect.clear();
        prodiSelect.clear();
        approvedBySelect.clear();
        dosenSelect.clear();

        $("#modalAdd").on("hidden.bs.modal", () => {
            userSelect.clear();
            prodiSelect.clear();
            approvedBySelect.clear();
            dosenSelect.clear();
            $("#frmAdd").trigger("reset");
        });

        $("#modalAdd").on("shown.bs.modal", () => {
            userSelect.clear();
            prodiSelect.clear();
            approvedBySelect.clear();
            dosenSelect.clear();
            $("#frmAdd").trigger("reset");
        });
    });

    const thisPage = {

        loadData: () => {
            Common.ajaxReq({
                url: BASEURL('req/getRps')
            }, (res) => {
                if(res.length > 0) {
                    thisPage.data = res;
                    Common.renderToTable("#datatable", res, (i, v) => {
                        return `<tr>
                                <td>${v.matkul}</td>
                                <td>${v.kode_matkul}</td>
                                <td>${v.prodi?.nama}</td>
                                <td>${v.approved === 1 ? 'DISETUJUI' : 'BELUM DISETUJUI'}</td>
                                <td>${v.publish === 1 ? (v.approved === 0 ? 'PENDING' : 'PUBLISH') : 'DRAFT'}</td>
                                <td>${Common.formatDate(v.created_at)}</td>
                                <td>${Common.formatDate(v.updated_at)}</td>
                                <td class="text-center">
                                    <button type="button" onclick="location.href='<?= base_url() ?>rps/detail/${v.id}'" class="btn badge bg-info text-white"><i class="ri-eye-line"></i></button>
                                    <button type="button" onclick="thisPage.getData(${v.id})" class="btn badge bg-primary text-white"><i class="ri-edit-line"></i></button>
                                    <button type="button" class="btn badge bg-danger text-white" onclick="thisPage.deleteData(${v.id})"><i class="ri-delete-bin-line"></i></button>
                                </td>
                            </tr>`;
                    }, true);
                } else {
                    Common.thisAlert("Error", "Failed To Load Datatable", "error");
                }
            }, (jqXHR) => {
                Common.thisAlert("Error", "Failed To Load Datatable", "error");
            });
        },

        addData: () => {
            Common.ajaxReq({
                url: BASEURL('req/insertRps'),
                data: $("#frmAdd").serialize(),
                type: "POST",
                beforeSend: () => {
                    $("#frmAdd button.btn-primary").attr("disabled", true).html("Loading...");
                }
            }, (res) => {
                if(res.status) {
                    Common.resetDatatable("#datatable", thisPage.loadData);
                    Common.thisAlert("Add", res.message, "success");
                } else {
                    Common.thisAlert("Add", res.message, "error");
                }
                
                $("#modalAdd").modal("hide");
                $("#frmAdd").trigger("reset");
                $("#frmAdd button.btn-primary").removeAttr("disabled").html(`<i class="ri-add-line"></i>&nbsp; Tambah`);
            }, (err) => {
                Common.thisAlert("Add", "Failed Failed To Add Data", "error");
                $("#modalAdd").modal("hide");
                $("#frmAdd button.btn-primary").removeAttr("disabled").html(`<i class="ri-add-line"></i>&nbsp; Tambah`);
            });
        },

        getData: (id) => {
            if(thisPage.data.length > 0) {
                let data = thisPage.data.filter(item => item.id === id);
                if(data.length > 0) {
                    data = data[0];
                    $("#modalEdit").modal("show");
                    
                    let edituserSelect = new TomSelect('#modalEdit #creator_id', { allowEmptyOption: true });
                    let editprodiSelect = new TomSelect('#modalEdit #prodi_id', { allowEmptyOption: true });
                    let editapprovedBySelect = new TomSelect('#modalEdit #approved_by', { allowEmptyOption: true });
                    let editdosenSelect = new TomSelect('#modalEdit #dosen', { allowEmptyOption: false });

                    $("#frmEdit #id").val(data.id);
                    $("#frmEdit #matkul").val(data.matkul);
                    $("#frmEdit #kode_matkul").val(data.kode_matkul);
                    $("#frmEdit #semester").val(data.semester);
                    $("#frmEdit #sks").val(data.sks);
                    $("#frmEdit #pertemuan").val(data.pertemuan);
                    $("#frmEdit #publish").val(data.publish);
                    $("#frmEdit #approved").val(data.approved);

                    edituserSelect.setValue(data.creator.user_id);
                    editprodiSelect.setValue(data.prodi_id);
                    editapprovedBySelect.setValue(data.approved_by);

                    if(data.rps_dosen.length > 0) {
                        let arrayDosen = [];
                        $.each(data.rps_dosen, (i, v) => {
                            arrayDosen.push(v.dosen.id);
                        });
                        editdosenSelect.setValue(arrayDosen);
                    }

                    $("#modalEdit").on("hidden.bs.modal", () => {
                        edituserSelect.destroy();
                        editprodiSelect.destroy();
                        editapprovedBySelect.destroy();
                        editdosenSelect.destroy();
                    });
                } else {
                    $("#modalEdit").modal("hide");
                }
            } else {
                Common.thisAlert("Edit", "Failed Failed To Get Data", "error");
            }
        },

        updateData: () => {
            Common.ajaxReq({
                url: BASEURL('req/updateRps'),
                data: $("#frmEdit").serialize(),
                type: "POST",
                beforeSend: () => {
                    $("#frmEdit button.btn-primary").attr("disabled", true).html("Loading...");
                }
            }, (res) => {
                if(res.status) {
                    Common.resetDatatable("#datatable", thisPage.loadData);
                    Common.thisAlert("Edit", res.message, "success");
                } else {
                    Common.thisAlert("Edit", res.message, "error");
                }
                
                $("#modalEdit").modal("hide");
                $("#frmEdit").trigger("reset");
                $("#frmEdit button.btn-primary").removeAttr("disabled").html(`<i class="ri-save-line"></i>&nbsp; Simpan`);
            }, (err) => {
                Common.thisAlert("Edit", "Failed Failed To Add Data", "error");
                $("#modalEdit").modal("hide");
                $("#frmEdit button.btn-primary").removeAttr("disabled").html(`<i class="ri-save-line"></i>&nbsp; Simpan`);
            });
        },

        deleteData: (id) => {
            Common.thisAlert("Delete", "Are You Sure<br />Want To Delete This Item ?", "question", Common.mixinTA({
                showCancelButton: true,
                confirmButtonText: "Delete",
                confirmButtonColor: "var(--bs-danger)",
                cancelButtonText: "Cancel",
                cancelButtonColor: "var(--bs-secondary)"
            })).then((result) => {
                if(result.isConfirmed) {
                    Common.ajaxReq({
                        url: BASEURL(`req/deleteRps/${id}`),
                        type: "POST"
                    }, (res) => {
                        if(res.status) {
                            Common.resetDatatable("#datatable", thisPage.loadData);
                            Common.thisAlert("Delete", "Item deleted successfully", "success");
                        } else {
                            Common.thisAlert("Delete", res.message, "error");
                        }
                    }, (err) => {
                        Common.thisAlert("Delete", "Failed to delete item", "error");
                    });
                }
            });
        }

    }

</script>