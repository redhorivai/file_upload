<div class="table-responsive">
    <table class="table table-striped table-bordered" id="datatable">
        <thead>
            <tr>
                <th class="bg-dark text-white">Kode</th>
                <th class="bg-dark text-white">Name</th>
                <th class="bg-dark text-white">Program Pendidikan</th>
            </tr>
        </thead>
        <tbody></tbody>
    </table>
</div>

<script>

    $(document).ready(() => {
        thisPage.loadData();
    });

    const thisPage = {

        loadData: () => {
            Common.ajaxReq({
                url: BASEURL('req/getMasterProdi')
            }, (res) => {
                if(res.length > 0) {
                    thisPage.data = res;
                    Common.renderToTable("#datatable", res, (i, v) => {
                        return `<tr>
                                <td>${v.kode}</td>
                                <td>${v.nama}</td>
                                <td>${v.content.program_pendidikan || ''}</td>
                            </tr>`;
                    }, true);
                } else {
                    Common.thisAlert("Error", "Failed To Load Datatable", "error");
                }
            }, (jqXHR) => {
                Common.thisAlert("Error", "Failed To Load Datatable", "error");
            });
        },

    }

</script>