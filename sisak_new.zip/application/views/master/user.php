<div class="mb-3 d-flex justify-content-between">
    <div>&nbsp;</div>
    <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#modalAdd">
        <i class="ri-add-line"></i>&nbsp; Tambah
    </button>
</div>

<!-- ========================================== MODAL ========================================== --->
<!-- ADD -->
<div class="modal fade" id="modalAdd" tabindex="-1" aria-labelledby="modalAddLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-dialog-scorllable modal-fullscreen">
        <div class="modal-content">
            <div class="modal-header">
                <h1 class="modal-title fs-5" id="modalAddLabel">Tambah User</h1>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <form id="frmAdd">
                    <div class="container">
                        <div class="form-floating mb-3">
                            <input type="text" class="form-control" name="nama" id="nama" placeholder="-">
                            <label for="nama">Nama</label>
                        </div>
                        <div class="mb-3 form-floating">
                            <input type="email" class="form-control" name="email" id="email" placeholder="-">
                            <label for="email">Email</label>
                        </div>
                        <div class="mb-3 form-floating">
                            <input type="text" class="form-control" name="username" id="username" placeholder="-">
                            <label for="username">Username</label>
                        </div>
                        <div class="mb-3 form-floating">
                            <select type="text" class="form-control" name="status" id="status" placeholder="-">
                                <option value="">- Pilih Status -</option>
                                <option value="1">Aktif</option>
                                <option value="0">Tidak Aktif</option>
                            </select>
                            <label for="status">Status</label>
                        </div>
                        <div class="mb-3 form-floating">
                            <span class="show-password" id="sh" onclick="Common.showHide('#frmAdd #password', '#frmAdd #sh')"><i class="ri-eye-off-line"></i></span>
                            <input type="password" class="form-control" name="password" id="password" placeholder="-">
                            <label for="password">Password</label>
                        </div>
                        <button type="button" class="btn btn-primary" onclick="thisPage.addData()"><i class="ri-add-line"></i>&nbsp; Tambah</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<!-- EDIT -->
<div class="modal fade" id="modalEdit" tabindex="-1" aria-labelledby="modalEditLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-dialog-scorllable modal-fullscreen">
        <div class="modal-content">
            <div class="modal-header">
                <h1 class="modal-title fs-5" id="modalEditLabel">Edit User</h1>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <form id="frmEdit">
                    <input type="hidden" name="id" id="id">
                    <div class="container">
                        <div class="form-floating mb-3">
                            <input type="text" class="form-control" name="nama" id="nama" placeholder="-">
                            <label for="nama">Nama</label>
                        </div>
                        <div class="mb-3 form-floating">
                            <input type="hidden" name="old_email" id="old_email">
                            <input type="email" class="form-control" name="email" id="email" placeholder="-">
                            <label for="email">Email</label>
                        </div>
                        <div class="mb-3 form-floating">
                            <input type="text" class="form-control" name="username" id="username" placeholder="-">
                            <label for="username">Username</label>
                        </div>
                        <div class="mb-3 form-floating">
                            <select type="text" class="form-control" name="status" id="status" placeholder="-">
                                <option value="">- Pilih Status -</option>
                                <option value="1">Aktif</option>
                                <option value="0">Tidak Aktif</option>
                            </select>
                            <label for="status">Status</label>
                        </div>
                        <div class="mb-3 form-floating">
                            <span class="show-password" id="sh" onclick="Common.showHide('#frmEdit #password', '#frmEdit #sh')"><i class="ri-eye-off-line"></i></span>
                            <input type="password" class="form-control" name="password" id="password" placeholder="-">
                            <label for="password">Password Baru</label>
                        </div>
                        <button type="button" class="btn btn-primary" onclick="thisPage.updateData()"><i class="ri-save-line"></i>&nbsp; Simpan</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<!-- ========================================== MODAL ========================================== --->

<div class="table-responsive">
    <table class="table table-striped table-bordered" id="datatable">
        <thead>
            <tr>
                <th class="bg-dark text-white">Name</th>
                <th class="bg-dark text-white">Email</th>
                <th class="bg-dark text-white">Username</th>
                <th class="bg-dark text-white">Role</th>
                <th class="bg-dark text-white">Status</th>
                <th class="bg-dark text-white">Created At</th>
                <th class="bg-dark text-white">Update At</th>
                <th class="bg-dark text-white">#</th>
            </tr>
        </thead>
        <tbody></tbody>
    </table>
</div>

<script>

    $(document).ready(() => {
        thisPage.loadData();
    });

    const thisPage = {

        loadData: () => {
            Common.ajaxReq({
                url: BASEURL('req/getMasterUser')
            }, (res) => {
                if(res.length > 0) {
                    thisPage.data = res;
                    Common.renderToTable("#datatable", res, (i, v) => {
                        return `<tr>
                                <td>${v.name}</td>
                                <td>${v.email}</td>
                                <td>${v.username}</td>
                                <td>${v.role}</td>
                                <td class="text-center">${(v.active ? '<i class="ri-checkbox-circle-line text-success"></i>' : '<i class="ri-close-circle-line text-danger"></i>')}</td>
                                <td>${Common.formatDate(v.created_at)}</td>
                                <td>${Common.formatDate(v.updated_at)}</td>
                                <td class="text-center">
                                    <button type="button" onclick="thisPage.getData(${v.id});" class="btn badge bg-primary text-white"><i class="ri-edit-line"></i></button>
                                    <button type="button" class="btn badge bg-danger text-white${v.role !== "Unknown" ? ' d-none' : ''}" onclick="thisPage.deleteData(${v.id})"><i class="ri-delete-bin-line"></i></button>
                                </td>
                            </tr>`;
                    }, true);
                } else {
                    Common.thisAlert("Error", "Failed To Load Datatable", "error");
                }
            }, (jqXHR) => {
                Common.thisAlert("Error", "Failed To Load Datatable", "error");
            });
        },

        addData: () => {
            Common.ajaxReq({
                url: BASEURL('req/insertMasterUser'),
                data: $("#frmAdd").serialize(),
                type: "POST",
                beforeSend: () => {
                    $("#frmAdd button.btn-primary").attr("disabled", true).html("Loading...");
                }
            }, (res) => {
                if(res.status) {
                    Common.resetDatatable("#datatable", thisPage.loadData);
                    Common.thisAlert("Add", res.message, "success");
                } else {
                    Common.thisAlert("Add", res.message, "error");
                }
                
                $("#modalAdd").modal("hide");
                $("#frmAdd").trigger("reset");
                $("#frmAdd button.btn-primary").removeAttr("disabled").html(`<i class="ri-add-line"></i>&nbsp; Tambah`);
            }, (err) => {
                Common.thisAlert("Add", "Failed Failed To Add Data", "error");
                $("#modalAdd").modal("hide");
                $("#frmAdd button.btn-primary").removeAttr("disabled").html(`<i class="ri-add-line"></i>&nbsp; Tambah`);
            });
        },

        getData: (id) => {
            if(thisPage.data.length > 0) {
                let data = thisPage.data.filter(item => item.id === id);
                if(data.length > 0) {
                    data = data[0];
                    $("#modalEdit").modal("show");

                    $("#frmEdit #id").val(data.id);
                    $("#frmEdit #nama").val(data.name);
                    $("#frmEdit #email").val(data.email);
                    $("#frmEdit #old_email").val(data.email);
                    $("#frmEdit #username").val(data.username);
                    $("#frmEdit #status").val(data.active);
                } else {
                    $("#modalEdit").modal("hide");
                }
            } else {
                Common.thisAlert("Edit", "Failed Failed To Get Data", "error");
            }
        },

        updateData: () => {
            Common.ajaxReq({
                url: BASEURL('req/updateMasterUser'),
                data: $("#frmEdit").serialize(),
                type: "POST",
                beforeSend: () => {
                    $("#frmEdit button.btn-primary").attr("disabled", true).html("Loading...");
                }
            }, (res) => {
                if(res.status) {
                    Common.resetDatatable("#datatable", thisPage.loadData);
                    Common.thisAlert("Edit", res.message, "success");
                } else {
                    Common.thisAlert("Edit", res.message, "error");
                }
                
                $("#modalEdit").modal("hide");
                $("#frmEdit").trigger("reset");
                $("#frmEdit button.btn-primary").removeAttr("disabled").html(`<i class="ri-save-line"></i>&nbsp; Simpan`);
            }, (err) => {
                Common.thisAlert("Edit", "Failed Failed To Add Data", "error");
                $("#modalEdit").modal("hide");
                $("#frmEdit button.btn-primary").removeAttr("disabled").html(`<i class="ri-save-line"></i>&nbsp; Simpan`);
            });
        },

        deleteData: (id) => {
            Common.thisAlert("Delete", "Are You Sure<br />Want To Delete This Item ?", "question", Common.mixinTA({
                showCancelButton: true,
                confirmButtonText: "Delete",
                confirmButtonColor: "var(--bs-danger)",
                cancelButtonText: "Cancel",
                cancelButtonColor: "var(--bs-secondary)"
            })).then((result) => {
                if(result.isConfirmed) {
                    Common.ajaxReq({
                        url: BASEURL(`req/deleteMasterUser/${id}`),
                        type: "POST"
                    }, (res) => {
                        if(res.status) {
                            Common.resetDatatable("#datatable", thisPage.loadData);
                            Common.thisAlert("Delete", "Item deleted successfully", "success");
                        } else {
                            Common.thisAlert("Delete", res.message, "error");
                        }
                    }, (err) => {
                        Common.thisAlert("Delete", "Failed to delete item", "error");
                    });
                }
            });
        }

    }

</script>