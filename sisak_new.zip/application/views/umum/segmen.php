<div class="table-responsive">
    <table class="table table-striped table-bordered" id="datatable">
        <thead>
            <tr>
                <th class="bg-dark text-white">Name</th>
            </tr>
        </thead>
        <tbody></tbody>
    </table>
</div>

<script>

    $(document).ready(() => {
        thisPage.loadData();
    });

    const thisPage = {

        loadData: () => {
            Common.ajaxReq({
                url: BASEURL('req/getUmumSegmen'),
            }, (res) => {
                if(res.length > 0) {
                    Common.renderToTable("#datatable", res, (i, v) => {
                        return `<tr>
                            <td>${v.title}</td>
                        </tr>`;
                    }, false);
                }
            }, (jqXHR) => {});
        }

    }

</script>