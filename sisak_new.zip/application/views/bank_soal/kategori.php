<div class="mb-3 d-flex justify-content-between">
    <div>&nbsp;</div>
    <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#modalAdd">
        <i class="ri-add-line"></i>&nbsp; Tambah
    </button>
</div>

<!-- ========================================== MODAL ========================================== --->
<!-- ADD -->
<div class="modal fade" id="modalAdd" tabindex="-1" aria-labelledby="modalAddLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-dialog-scorllable modal-fullscreen">
        <div class="modal-content">
            <div class="modal-header">
                <h1 class="modal-title fs-5" id="modalAddLabel">Tambah Dosen</h1>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <form id="frmAdd">
                    <div class="container">
                        <div class="mb-3">
                            <label class="fw-bold mb-2 d-block">Dibuat Oleh</label>
                            <select name="creator_id" id="creator_id" placeholder="Cari nama">
                                <?php
                                    foreach($user as $index => $value) {
                                            echo "<option value='". $value->id ."'>". $value->name ."</option>";
                                    }
                                ?>
                            </select>
                        </div>
                        <div class="mb-3 form-floating">
                            <input type="text" class="form-control" name="nama" id="nama" placeholder="-">
                            <label for="nama">Nama</label>
                        </div>
                        <div class="mb-3 form-floating">
                            <textarea type="text" class="form-control" name="keterangan" id="keterangan" placeholder="-" style="height: 100px"></textarea>
                            <label for="keterangan">Keterangan</label>
                        </div>
                        <button type="button" class="btn btn-primary" onclick="thisPage.addData()"><i class="ri-add-line"></i>&nbsp; Tambah</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<!-- EDIT -->
<div class="modal fade" id="modalEdit" tabindex="-1" aria-labelledby="modalEditLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-dialog-scorllable modal-fullscreen">
        <div class="modal-content">
            <div class="modal-header">
                <h1 class="modal-title fs-5" id="modalEditLabel">Edit Dosen</h1>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <form id="frmEdit">
                    <input type="hidden" name="id" id="id">
                    <div class="container">
                        <div class="mb-3">
                            <label class="fw-bold mb-2 d-block">Dibuat Oleh</label>
                            <select name="creator_id" id="creator_id" placeholder="Cari nama">
                                <?php
                                    foreach($user as $index => $value) {
                                            echo "<option value='". $value->id ."'>". $value->name ."</option>";
                                    }
                                ?>
                            </select>
                        </div>
                        <div class="mb-3 form-floating">
                            <input type="text" class="form-control" name="nama" id="nama" placeholder="-">
                            <label for="nama">Nama</label>
                        </div>
                        <div class="mb-3 form-floating">
                            <textarea type="text" class="form-control" name="keterangan" id="keterangan" placeholder="-" style="height: 100px"></textarea>
                            <label for="keterangan">Keterangan</label>
                        </div>
                        <button type="button" class="btn btn-primary" onclick="thisPage.updateData()"><i class="ri-save-line"></i>&nbsp; Simpan</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<!-- ========================================== MODAL ========================================== --->

<div class="table-responsive">
    <table class="table table-striped table-bordered" id="datatable">
        <thead>
            <tr>
                <th class="bg-dark text-white">Name</th>
                <th class="bg-dark text-white">Keterangan</th>
                <th class="bg-dark text-white">Jumlah Soal</th>
                <th class="bg-dark text-white">Created At</th>
                <th class="bg-dark text-white">Updated At</th>
                <th class="bg-dark text-white">#</th>
            </tr>
        </thead>
        <tbody></tbody>
    </table>
</div>

<script>
    var prodiSelect;

    $(document).ready(() => {
        thisPage.loadData();

        prodiSelect = new TomSelect('#modalAdd #creator_id', { allowEmptyOption: true });
        prodiSelect.clear();

        $("#modalAdd").on("hidden.bs.modal", () => {
            prodiSelect.clear();
        });

        $("#modalAdd").on("shown.bs.modal", () => {
            prodiSelect.clear();
        });
    });

    const thisPage = {

        loadData: () => {
            Common.ajaxReq({
                url: BASEURL('req/getBankSoalKategori')
            }, (res) => {
                if(res.length > 0) {
                    thisPage.data = res;
                    Common.renderToTable("#datatable", res, (i, v) => {
                        return `<tr>
                                <td>${v.nama}</td>
                                <td>${v.keterangan}</td>
                                <td class="text-center">${v.soal.length}</td>
                                <td>${Common.formatDate(v.created_at)}</td>
                                <td>${Common.formatDate(v.updated_at)}</td>
                                <td class="text-center">
                                    <button type="button" onclick="thisPage.getData(${v.id})" class="btn badge bg-primary text-white"><i class="ri-edit-line"></i></button>
                                    <button type="button" class="btn badge bg-danger text-white" onclick="thisPage.deleteData(${v.id})"><i class="ri-delete-bin-line"></i></button>
                                </td>
                            </tr>`;
                    }, true);
                } else {
                    Common.thisAlert("Error", "Failed To Load Datatable", "error");
                }
            }, (jqXHR) => {
                Common.thisAlert("Error", "Failed To Load Datatable", "error");
            });
        },

        addData: () => {
            Common.ajaxReq({
                url: BASEURL('req/insertBankSoalKategori'),
                data: $("#frmAdd").serialize(),
                type: "POST",
                beforeSend: () => {
                    $("#frmAdd button.btn-primary").attr("disabled", true).html("Loading...");
                }
            }, (res) => {
                if(res.status) {
                    Common.resetDatatable("#datatable", thisPage.loadData);
                    Common.thisAlert("Add", res.message, "success");
                } else {
                    Common.thisAlert("Add", res.message, "error");
                }
                
                $("#modalAdd").modal("hide");
                $("#frmAdd").trigger("reset");
                $("#frmAdd button.btn-primary").removeAttr("disabled").html(`<i class="ri-add-line"></i>&nbsp; Tambah`);
            }, (err) => {
                Common.thisAlert("Add", "Failed Failed To Add Data", "error");
                $("#modalAdd").modal("hide");
                $("#frmAdd button.btn-primary").removeAttr("disabled").html(`<i class="ri-add-line"></i>&nbsp; Tambah`);
            });
        },

        getData: (id) => {
            if(thisPage.data.length > 0) {
                let data = thisPage.data.filter(item => item.id === id);
                if(data.length > 0) {
                    data = data[0];
                    $("#modalEdit").modal("show");

                    let creatorIdSelect = new TomSelect('#frmEdit #creator_id', { allowEmptyOption: true });
                    
                    $("#frmEdit #id").val(data.id);
                    $("#frmEdit #nama").val(data.nama);
                    $("#frmEdit #keterangan").val(data.keterangan);
                    creatorIdSelect.setValue(data.creator_id);

                    $("#modalEdit").on("hidden.bs.modal", () => {
                        creatorIdSelect.destroy();
                    });
                } else {
                    $("#modalEdit").modal("hide");
                }
            } else {
                Common.thisAlert("Edit", "Failed Failed To Get Data", "error");
            }
        },

        updateData: () => {
            Common.ajaxReq({
                url: BASEURL('req/updateBankSoalKategori'),
                data: $("#frmEdit").serialize(),
                type: "POST",
                beforeSend: () => {
                    $("#frmEdit button.btn-primary").attr("disabled", true).html("Loading...");
                }
            }, (res) => {
                if(res.status) {
                    Common.resetDatatable("#datatable", thisPage.loadData);
                    Common.thisAlert("Edit", res.message, "success");
                } else {
                    Common.thisAlert("Edit", res.message, "error");
                }
                
                $("#modalEdit").modal("hide");
                $("#frmEdit").trigger("reset");
                $("#frmEdit button.btn-primary").removeAttr("disabled").html(`<i class="ri-save-line"></i>&nbsp; Simpan`);
            }, (err) => {
                Common.thisAlert("Edit", "Failed Failed To Add Data", "error");
                $("#modalEdit").modal("hide");
                $("#frmEdit button.btn-primary").removeAttr("disabled").html(`<i class="ri-save-line"></i>&nbsp; Simpan`);
            });
        },

        deleteData: (id) => {
            Common.thisAlert("Delete", "Are You Sure<br />Want To Delete This Item ?", "question", Common.mixinTA({
                showCancelButton: true,
                confirmButtonText: "Delete",
                confirmButtonColor: "var(--bs-danger)",
                cancelButtonText: "Cancel",
                cancelButtonColor: "var(--bs-secondary)"
            })).then((result) => {
                if(result.isConfirmed) {
                    Common.ajaxReq({
                        url: BASEURL(`req/deleteBankSoalKategori/${id}`),
                        type: "POST"
                    }, (res) => {
                        if(res.status) {
                            Common.resetDatatable("#datatable", thisPage.loadData);
                            Common.thisAlert("Delete", "Item deleted successfully", "success");
                        } else {
                            Common.thisAlert("Delete", res.message, "error");
                        }
                    }, (err) => {
                        Common.thisAlert("Delete", "Failed to delete item", "error");
                    });
                }
            });
        }

    }

</script>