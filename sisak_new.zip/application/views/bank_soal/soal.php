<div class="mb-3 d-flex justify-content-between">
    <div>&nbsp;</div>
    <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#modalAdd">
        <i class="ri-add-line"></i>&nbsp; Tambah
    </button>
</div>

<!-- ========================================== MODAL ========================================== --->
<!-- ADD -->
<div class="modal fade" id="modalAdd" tabindex="-1" aria-labelledby="modalAddLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-dialog-scorllable modal-fullscreen">
        <div class="modal-content">
            <div class="modal-header">
                <h1 class="modal-title fs-5" id="modalAddLabel">Tambah Soal</h1>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <form id="frmAdd">
                    <div class="container-fluid row">
                        <div class="col-sm-6 border-end border-secondary">
                            <div class="mb-3">
                                <label class="fw-bold mb-2 d-block">Pembuat Soal</label>
                                <select name="creator_id" id="creator_id" placeholder="Cari nama">
                                    <?php
                                        foreach($user as $index => $value) {
                                            echo "<option value='$value->id'>$value->name</option>";
                                        }
                                    ?>
                                </select>
                            </div>
                            <div class="mb-3">
                                <label class="fw-bold mb-2 d-block">Kategori Soal</label>
                                <select name="kategori_id" id="kategori_id" placeholder="Cari nama">
                                    <?php
                                        foreach($kategori as $index => $value) {
                                            echo "<option value='$value->id'>$value->nama</option>";
                                        }
                                    ?>
                                </select>
                            </div>
                            <div class="mb-3">
                                <textarea id="pertanyaan"></textarea>
                            </div>
                        </div>
                        <div class="col-sm-6">
                            <div class="mb-3 form-floating">
                                <select type="text" class="form-select" name="tipe_jawaban" id="tipe_jawaban" onchange="thisPage.changeJawaban(this.value, 'frmEdit')">
                                    <option value="">- Pilih Tipe Jawaban -</option>
                                    <?php
                                        foreach($tipe_jawaban as $key => $val) {
                                            echo "<option value='". $key ."'>". $val->title ."</option>";
                                        }
                                    ?>
                                </select>
                                <label for="">Tipe Jawaban</label>
                            </div>
                            <div id="tipeJawabanResult"></div>
                        </div>
                        <div class="col-sm-12 mt-3">
                            <button type="button" class="btn btn-primary" onclick="thisPage.addData()"><i class="ri-add-line"></i>&nbsp; Tambah</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<!-- EDIT -->
<div class="modal fade" id="modalEdit" tabindex="-1" aria-labelledby="modalEditLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-dialog-scorllable modal-fullscreen">
        <div class="modal-content">
            <div class="modal-header">
                <h1 class="modal-title fs-5" id="modalEditLabel">Edit Soal</h1>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <form id="frmEdit">
                    <input type="hidden" name="id" id="id">
                    <div class="container-fluid row">
                        <div class="col-sm-6 border-end border-secondary">
                            <div class="mb-3">
                                <label class="fw-bold mb-2 d-block">Pembuat Soal</label>
                                <select name="creator_id" id="creator_id" placeholder="Cari nama">
                                    <?php
                                        foreach($user as $index => $value) {
                                            echo "<option value='$value->id'>$value->name</option>";
                                        }
                                    ?>
                                </select>
                            </div>
                            <div class="mb-3">
                                <label class="fw-bold mb-2 d-block">Kategori Soal</label>
                                <select name="kategori_id" id="kategori_id" placeholder="Cari nama">
                                    <?php
                                        foreach($kategori as $index => $value) {
                                            echo "<option value='$value->id'>$value->nama</option>";
                                        }
                                    ?>
                                </select>
                            </div>
                            <div class="mb-3">
                                <textarea id="pertanyaanEdit"></textarea>
                            </div>
                        </div>
                        <div class="col-sm-6">
                            <div class="mb-3 form-floating">
                                <select type="text" class="form-select" name="tipe_jawaban" id="tipe_jawaban" onchange="thisPage.changeJawaban(this.value, 'frmEdit')">
                                    <option value="">- Pilih Tipe Jawaban -</option>
                                    <?php
                                        foreach($tipe_jawaban as $key => $val) {
                                            echo "<option value='". $key ."'>". $val->title ."</option>";
                                        }
                                    ?>
                                </select>
                                <label for="">Tipe Jawaban</label>
                            </div>
                            <div id="tipeJawabanResult"></div>
                        </div>
                        <div class="col-sm-12 mt-3">
                            <button type="button" class="btn btn-primary" onclick="thisPage.updateData()"><i class="ri-save-line"></i>&nbsp; Simpan</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<!-- ========================================== MODAL ========================================== --->

<div class="table-responsive">
    <table class="table table-striped table-bordered" id="datatable">
        <thead>
            <tr>
                <th class="bg-dark text-white">Kategori</th>
                <th class="bg-dark text-white">Pembuat Soal</th>
                <th class="bg-dark text-white">Tipe</th>
                <th class="bg-dark text-white">Created At</th>
                <th class="bg-dark text-white">Updated At</th>
                <th class="bg-dark text-white">#</th>
            </tr>
        </thead>
        <tbody></tbody>
    </table>
</div>

<script>
    var userSelect;
    var kategoriSelect;

    $(document).ready(() => {
        thisPage.loadData();

        userSelect = new TomSelect('#modalAdd #creator_id', { allowEmptyOption: true });
        kategoriSelect = new TomSelect('#modalAdd #kategori_id', { allowEmptyOption: true });
        userSelect.clear();
        kategoriSelect.clear();

        $("#modalAdd").on("hidden.bs.modal", () => {
            userSelect.clear();
            kategoriSelect.clear();
            $("#modalAdd #tipeJawabanResult").html("");
            $("#frmAdd").trigger("reset");
        });

        $("#modalAdd").on("shown.bs.modal", () => {
            userSelect.clear();
            kategoriSelect.clear();
            $("#modalAdd #tipeJawabanResult").html("");
            $("#frmAdd").trigger("reset");
        });

        tinymce.init({
            selector: '#pertanyaan',
            height: 500,
            plugins: 'advlist autolink lists link image media charmap preview anchor textcolor code emoticons',
            toolbar: 'undo redo | blocks fontfamily fontsize | code | bold italic underline strikethrough | link image media table | align lineheight | numlist bullist indent outdent | emoticons charmap | removeformat',
            menubar: 'file edit view insert format tools table help',
            setup: function (editor) {
                editor.on('init', function () {
                console.log('TinyMCE editor initialized.');
                });
            }
        });

        tinymce.init({
            selector: '#pertanyaanEdit',
            height: 500,
            plugins: 'advlist autolink lists link image media charmap preview anchor textcolor code emoticons',
            toolbar: 'undo redo | blocks fontfamily fontsize | code | bold italic underline strikethrough | link image media table | align lineheight | numlist bullist indent outdent | emoticons charmap | removeformat',
            menubar: 'file edit view insert format tools table help',
            setup: function (editor) {
                editor.on('init', function () {
                console.log('TinyMCE editor initialized.');
                });
            }
        });
    });

    const thisPage = {

        lastId: 1,

        loadData: () => {
            Common.ajaxReq({
                url: BASEURL('req/getBankSoalSoal')
            }, (res) => {
                if(res.length > 0) {
                    thisPage.data = res;
                    Common.renderToTable("#datatable", res, (i, v) => {
                        let tipeJawaban = "";
                        switch(v.tipe_jawaban.toString()) {
                            case "0" : tipeJawaban = "Multiple Choice"; break;
                            case "1" : tipeJawaban = "Exact"; break;
                            case "2" : tipeJawaban = "Essay"; break;
                            case "3" : tipeJawaban = "TRUE / FALSE"; break;
                            default : tipeJawaban = "Unknown"; break;
                        }
                        
                        return `<tr>
                                <td>${v.kategori?.nama}</td>
                                <td>${v.creator?.name}</td>
                                <td>${tipeJawaban}</td>
                                <td>${Common.formatDate(v.created_at)}</td>
                                <td>${Common.formatDate(v.updated_at)}</td>
                                <td class="text-center">
                                    <button type="button" onclick="thisPage.getData(${v.id})" class="btn badge bg-primary text-white"><i class="ri-edit-line"></i></button>
                                    <button type="button" class="btn badge bg-danger text-white" onclick="thisPage.deleteData(${v.id})"><i class="ri-delete-bin-line"></i></button>
                                </td>
                            </tr>`;
                    }, true);
                } else {
                    Common.thisAlert("Error", "Failed To Load Datatable", "error");
                }
            }, (jqXHR) => {
                Common.thisAlert("Error", "Failed To Load Datatable", "error");
            });
        },

        addData: () => {
            var content = tinymce.get('pertanyaan').getContent();
            var formData = $("#frmAdd").serializeArray();
            var data = {};
            $.each(formData, function(index, field) {
                if (data[field.name]) {
                    if (Array.isArray(data[field.name])) {
                        data[field.name].push(field.value);
                    } else {
                        data[field.name] = [data[field.name], field.value];
                    }
                } else {
                    data[field.name] = field.value;
                }
            });
            data['pertanyaan'] = content;

            Common.ajaxReq({
                url: BASEURL('req/insertBankSoal'),
                data: data,
                type: "POST",
                beforeSend: () => {
                    $("#frmAdd button.btn-primary").attr("disabled", true).html("Loading...");
                }
            }, (res) => {
                if(res.status) {
                    Common.resetDatatable("#datatable", thisPage.loadData);
                    Common.thisAlert("Add", res.message, "success");
                } else {
                    Common.thisAlert("Add", res.message, "error");
                }
                
                $("#modalAdd").modal("hide");
                $("#frmAdd").trigger("reset");
                $("#frmAdd button.btn-primary").removeAttr("disabled").html(`<i class="ri-add-line"></i>&nbsp; Tambah`);
            }, (err) => {
                Common.thisAlert("Add", "Failed Failed To Add Data", "error");
                $("#modalAdd").modal("hide");
                $("#frmAdd button.btn-primary").removeAttr("disabled").html(`<i class="ri-add-line"></i>&nbsp; Tambah`);
            });
        },

        getData: (id) => {
            if(thisPage.data.length > 0) {
                let data = thisPage.data.filter(item => item.id === id);
                if(data.length > 0) {
                    data = data[0];
                    $("#modalEdit").modal("show");

                    let creatorIdSelect = new TomSelect('#frmEdit #creator_id', { allowEmptyOption: true });
                    let kategoriIdSelect = new TomSelect('#frmEdit #kategori_id', { allowEmptyOption: true });
                    
                    $("#frmEdit #id").val(data.id);
                    $("#frmEdit #tipe_jawaban").val(data.tipe_jawaban);
                    tinymce.get('pertanyaanEdit').setContent(data.pertanyaan);
                    creatorIdSelect.setValue(data.creator_id);
                    kategoriIdSelect.setValue(data.kategori_id);

                    switch(data.tipe_jawaban.toString()) {
                        case "0" : 
                            let listPilihan = "";

                            $.each(data.pilihan, (k, v) => {
                                listPilihan += `<div class="mb-2" data-row="${thisPage.lastId + 1}">
                                    <div class="d-flex w-100">
                                        <div class="w-100 me-3">
                                            <input type="text" class="form-control" name="pilihan[]" placeholder="-" value="${v}">
                                        </div>
                                        <div class="w-100"><button type="button" class="btn btn-danger" onclick="$('#multipleChoice div[data-row=${thisPage.lastId + 1}]').remove();"><i class="ri-close-line"></i></button></div>
                                    </div>
                                </div>`;
                                thisPage.lastId++;
                            });

                            $("#modalEdit #tipeJawabanResult").html(`<hr />
                            <div class="mb-3 fs-5 fw-bold">Multiple Choice</div>
                            <button onclick="thisPage.addMultipleChoice()" type="button" class="btn btn-sm btn-primary mb-3"><i class="ri-add-line"></i>&nbsp; Tambah Pilihan</button>
                            <div id="multipleChoice" class="mb-3">
                                ${listPilihan}
                            </div>
                            <hr />
                            <div class="form-floating mb-3">
                                <input type="text" class="form-control" name="jawaban" id="jawaban" placeholder="-" value="${parseInt(data.jawaban)}">
                                <label for="jawaban">Jawaban Pada Nomor</label>
                            </div>`);
                            break;
                        case "1" : 
                            let listJawaban = "";

                            $.each(data.jawaban, (k, v) => {
                                listJawaban += `<div class="mb-2" data-row="${thisPage.lastId + 1}">
                                    <div class="d-flex w-100">
                                        <div class="w-100 me-3">
                                            <input type="text" class="form-control" name="jawaban[]" placeholder="-" value="${v}">
                                        </div>
                                        <div class="w-100"><button type="button" class="btn btn-danger" onclick="$('#multipleAnswer div[data-row=${thisPage.lastId + 1}]').remove();"><i class="ri-close-line"></i></button></div>
                                    </div>
                                </div>`;
                                thisPage.lastId++;
                            });

                            $("#modalEdit #tipeJawabanResult").html(`<hr />
                            <div class="mb-3 fs-5 fw-bold">Exact</div>
                            <button onclick="thisPage.addMultipleAnswer()" type="button" class="btn btn-sm btn-primary mb-3"><i class="ri-add-line"></i>&nbsp; Tambah Jawaban</button>
                            <div id="multipleAnswer">
                                ${listJawaban}
                            </div><hr />`);
                            break;
                        case "2" : result = `<hr />
                            <div class="mb-3 fs-5 fw-bold">Essay</div>`; 
                            break;
                        case "3" : 
                            $("#modalEdit #tipeJawabanResult").html(`<hr />
                                <div class="mb-3 fs-5 fw-bold">TRUE / FALSE</div>
                                <div class="form-floating mb-3">
                                <select type="text" class="form-select" name="jawaban" id="jawaban" placeholder="-">
                                    <option value="1" ${(data.jawaban === "1" || data.jawaban === 1 ? 'selected' : '')}>TRUE</option>
                                    <option value="0" ${(data.jawaban === "0" || data.jawaban === 0 ? 'selected' : '')}>FALSE</option>
                                </select>
                                <label for="jawaban">Jawaban</label>
                            </div>`);
                            break;
                        default : 
                            $("#modalEdit #tipeJawabanResult").html(``);
                            break;
                    }

                    $("#modalEdit").on("hidden.bs.modal", () => {
                        creatorIdSelect.destroy();
                        kategoriIdSelect.destroy();
                    });
                } else {
                    $("#modalEdit").modal("hide");
                }
            } else {
                Common.thisAlert("Edit", "Failed Failed To Get Data", "error");
            }
        },

        updateData: () => {
            var content = tinymce.get('pertanyaanEdit').getContent();
            var formData = $("#frmEdit").serializeArray();
            var data = {};
            $.each(formData, function(index, field) {
                if (data[field.name]) {
                    if (Array.isArray(data[field.name])) {
                        data[field.name].push(field.value);
                    } else {
                        data[field.name] = [data[field.name], field.value];
                    }
                } else {
                    data[field.name] = field.value;
                }
            });
            data['pertanyaan'] = content;

            Common.ajaxReq({
                url: BASEURL('req/updateBankSoal'),
                data:data,
                type: "POST",
                beforeSend: () => {
                    $("#frmEdit button.btn-primary").attr("disabled", true).html("Loading...");
                }
            }, (res) => {
                if(res.status) {
                    Common.resetDatatable("#datatable", thisPage.loadData);
                    Common.thisAlert("Edit", res.message, "success");
                } else {
                    Common.thisAlert("Edit", res.message, "error");
                }
                
                $("#modalEdit").modal("hide");
                $("#frmEdit").trigger("reset");
                $("#frmEdit button.btn-primary").removeAttr("disabled").html(`<i class="ri-save-line"></i>&nbsp; Simpan`);
            }, (err) => {
                Common.thisAlert("Edit", "Failed Failed To Add Data", "error");
                $("#modalEdit").modal("hide");
                $("#frmEdit button.btn-primary").removeAttr("disabled").html(`<i class="ri-save-line"></i>&nbsp; Simpan`);
            });
        },

        deleteData: (id) => {
            Common.thisAlert("Delete", "Are You Sure<br />Want To Delete This Item ?", "question", Common.mixinTA({
                showCancelButton: true,
                confirmButtonText: "Delete",
                confirmButtonColor: "var(--bs-danger)",
                cancelButtonText: "Cancel",
                cancelButtonColor: "var(--bs-secondary)"
            })).then((result) => {
                if(result.isConfirmed) {
                    Common.ajaxReq({
                        url: BASEURL(`req/deleteBankSoal/${id}`),
                        type: "POST"
                    }, (res) => {
                        if(res.status) {
                            Common.resetDatatable("#datatable", thisPage.loadData);
                            Common.thisAlert("Delete", "Item deleted successfully", "success");
                        } else {
                            Common.thisAlert("Delete", res.message, "error");
                        }
                    }, (err) => {
                        Common.thisAlert("Delete", "Failed to delete item", "error");
                    });
                }
            });
        },

        changeJawaban: (id, origin = "modalAdd") => {
            let result = "";

            switch(id) {
                case "0" : result = `<hr />
                    <div class="mb-3 fs-5 fw-bold">Multiple Choice</div>
                    <button onclick="thisPage.addMultipleChoice()" type="button" class="btn btn-sm btn-primary mb-3"><i class="ri-add-line"></i>&nbsp; Tambah Pilihan</button>
                    
                    <div id="multipleChoice" class="mb-3">
                        <div class="mb-2" data-row="1">
                            <div class="d-flex w-100">
                                <div class="w-100 me-3">
                                    <input type="text" class="form-control" name="pilihan[]" placeholder="-">
                                </div>
                                <div class="w-100"><button type="button" class="btn btn-danger" onclick="$('#tipeJawabanResult #multipleChoice div[data-row=1]').remove();"><i class="ri-close-line"></i></button></div>
                            </div>
                        </div>
                    </div>
                    <hr />
                    <div class="form-floating mb-3">
                        <input type="text" class="form-control" name="jawaban" id="jawaban" placeholder="-">
                        <label for="jawaban">Jawaban Pada Nomor</label>
                    </div>`; 
                    break;
                case "1" : result = `<hr />
                    <div class="mb-3 fs-5 fw-bold">Exact</div>
                    <button onclick="thisPage.addMultipleAnswer()" type="button" class="btn btn-sm btn-primary mb-3"><i class="ri-add-line"></i>&nbsp; Tambah Jawaban</button>
                    
                    <div id="multipleAnswer">
                        <div class="mb-2" data-row="1">
                            <div class="d-flex w-100">
                                <div class="w-100 me-3">
                                    <input type="text" class="form-control" name="jawaban[]" placeholder="-">
                                </div>
                                <div class="w-100"><button type="button" class="btn btn-danger" onclick="$('#tipeJawabanResult #multipleAnswer div[data-row=1]').remove();"><i class="ri-close-line"></i></button></div>
                            </div>
                        </div>
                    </div>`; 
                    break;
                case "2" : result = `<hr />
                    <div class="mb-3 fs-5 fw-bold">Essay</div>`; 
                    break;
                case "3" : result = `<hr />
                    <div class="mb-3 fs-5 fw-bold">TRUE / FALSE</div>
                    <div class="form-floating">
                        <select type="text" class="form-select" name="jawaban" id="jawaban" placeholder="-">
                            <option value="1">TRUE</option>
                            <option value="0">FALSE</option>
                        </select>
                        <label for="jawaban">Jawaban</label>
                    </div>`; 
                    break;
                default : result = "<hr />"; break;
            }

            $(`#${origin} #tipeJawabanResult`).html(result);
        },

        addMultipleChoice: () => {
            $("#multipleChoice").append(`<div class="mb-2" data-row="${thisPage.lastId + 1}">
                <div class="d-flex w-100">
                    <div class="w-100 me-3">
                        <input type="text" class="form-control" name="pilihan[]" placeholder="-">
                    </div>
                    <div class="w-100"><button type="button" class="btn btn-danger" onclick="$('#multipleChoice div[data-row=${thisPage.lastId + 1}]').remove();"><i class="ri-close-line"></i></button></div>
                </div>
            </div>`);
            thisPage.lastId++;
        },

        addMultipleAnswer: () => {
            $("#multipleAnswer").append(`
            <div class="mb-2" data-row="${thisPage.lastId + 1}">
                <div class="d-flex w-100">
                    <div class="w-100 me-3">
                        <input type="text" class="form-control" name="jawaban[]" placeholder="-">
                    </div>
                    <div class="w-100"><button type="button" class="btn btn-danger" onclick="$('#multipleAnswer div[data-row=${thisPage.lastId + 1}]').remove();"><i class="ri-close-line"></i></button></div>
                </div>
            </div>`);
            thisPage.lastId++;
        }

    }

</script>