<!DOCTYPE html>
<html lang="en">
<head>

    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title><?= (isset($title) ? $title ." - " : "") ?><?= $baseTitle ?></title>
    <link rel="shortcut icon" href="<?= base_url("images/favicon.ico") ?>" type="image/x-icon">
    <link rel="icon" href="<?= base_url("images/favicon.ico") ?>" type="image/x-icon">

    <link rel="stylesheet" href="<?= base_url('assets/css/common.css?v='. strtotime(date("Y-m-d H:i:s"))) ?>">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/remixicon@4.3.0/fonts/remixicon.css">
    <link href="https://cdn.jsdelivr.net/npm/tom-select@2.3.1/dist/css/tom-select.css" rel="stylesheet">
    <link href="https://cdn.datatables.net/v/bs5/jszip-3.10.1/dt-2.1.2/b-3.1.0/b-colvis-3.1.0/b-html5-3.1.0/b-print-3.1.0/r-3.0.2/datatables.min.css" rel="stylesheet">


    <script src="https://code.jquery.com/jquery-3.7.1.min.js" integrity="sha256-/JqT3SQfawRcv/BIHPThkBvs0OEvtFFmqPF/lYI/Cxo=" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script src="https://cdn.jsdelivr.net/npm/tom-select@2.3.1/dist/js/tom-select.complete.min.js"></script>
    <script src="https://cdn.tiny.cloud/1/ubqx5c93jglvpo3skxn6fgck9053fc40has7p097r8am5bkd/tinymce/7/tinymce.min.js" referrerpolicy="origin"></script>

    <script>
        const BASEURL = (path = false) => { return `<?= base_url() ?>${path ? path : ''}`; };
    </script>

</head>
<body class="bg-light">
    
    <div class="container">
        <!-- HEADER -->
        <header id="header" class="d-flex align-items-center justify-content-between py-4">
            <div id="header-left" class="d-flex align-items-center">
                <img src="http://sisak_poltekpar.com/elearning/images/logo.png" height="70px">
                <h3 class="ms-3 fw-bold">POLTEKPAR PALEMBANG</h3>
            </div>
            <div id="header-right" class="fw-light"></div>
        </header>

        <!-- NAVBAR -->
        <nav class="navbar navbar-expand-lg bg-white shadow-sm sticky-top">
            <div class="container-fluid">
                <a class="navbar-brand" href="/main.php"><i class="ri-function-line"></i>&nbsp; Menu</a>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                        
                        <li class="nav-item me-3">
                            <a class="nav-link" href="<?= base_url() ?>"><i class="ri-home-line"></i>&nbsp; Home</a>
                        </li>
                        <li class="nav-item dropdown me-3">
                            <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                                Umum
                            </a>
                            <ul class="dropdown-menu rounded-0">
                                <li><a class="dropdown-item" href="<?= base_url("umum/app_info") ?>">Informasi Aplikasi</a></li>
                                <li><a class="dropdown-item" href="<?= base_url("umum/prodi") ?>">Prodi</a></li>
                                <li><a class="dropdown-item" href="<?= base_url("umum/jawaban") ?>">Jawaban</a></li>
                                <li><a class="dropdown-item" href="<?= base_url("umum/materi") ?>">Materi</a></li>
                                <li><a class="dropdown-item" href="<?= base_url("umum/pertemuan") ?>">Pertemuan</a></li>
                                <li><a class="dropdown-item" href="<?= base_url("umum/ujian") ?>">Ujian</a></li>
                                <li><a class="dropdown-item" href="<?= base_url("umum/segmen") ?>">Segmen</a></li>
                                <li><a class="dropdown-item" href="<?= base_url("umum/role") ?>">Role</a></li>
                            </ul>
                        </li>
                        <li class="nav-item dropdown me-3">
                            <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                                Master Data
                            </a>
                            <ul class="dropdown-menu rounded-0">
                                <li><a class="dropdown-item" href="<?= base_url("master/user") ?>">User</a></li>
                                <li><a class="dropdown-item" href="<?= base_url("master/dosen") ?>">Dosen</a></li>
                                <li><a class="dropdown-item" href="<?= base_url("master/mahasiswa") ?>">Mahasiswa</a></li>
                                <li><a class="dropdown-item" href="<?= base_url("master/prodi") ?>">Prodi</a></li>
                            </ul>
                        </li>
                        <li class="nav-item dropdown me-3">
                            <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                                Bank Soal
                            </a>
                            <ul class="dropdown-menu rounded-0">
                                <li><a class="dropdown-item" href="<?= base_url("bank_soal/soal") ?>">Daftar Soal</a></li>
                                <li><a class="dropdown-item" href="<?= base_url("bank_soal/kategori") ?>">Daftar Kategori</a></li>
                            </ul>
                        </li>
                        <!-- <li class="nav-item me-3">
                            <a class="nav-link" href="<?= base_url() ?>">Bank Data</a>
                        </li>
                        <li class="nav-item me-3">
                            <a class="nav-link" href="<?= base_url() ?>">E-Course</a>
                        </li>
                        <li class="nav-item me-3">
                            <a class="nav-link" href="<?= base_url() ?>">Pengumuman</a>
                        </li>
                        <li class="nav-item me-3">
                            <a class="nav-link" href="<?= base_url() ?>">Sertifikat</a>
                        </li> -->
                        <!-- <li class="nav-item me-3">
                            <a class="nav-link" href="<?= base_url('pertemuan/') ?>">Pertemuan</a>
                        </li> -->
                        <li class="nav-item">
                            <a class="nav-link" href="<?= base_url('rps/rps') ?>">RPS/Penjadwalan</a>
                        </li>
                    </ul>
                </div>
            </div>
        </nav>

        <!-- CONTENT -->
        <div class="my-4">
            <div class="mb-4 fs-5 fw-bold text-secondary d-flex align-items-center justify-content-between">
                <div><?= (isset($titleIcon) && ($titleIcon !== null || $titleIcon !== "" || !empty($titleIcon)) ? '<i class="'. $titleIcon .'"></i>&nbsp; ' : '') ?><?= $title ?></div>
                <div style="font-size: 14px !important">
                    <a href="<?= base_url() ?>"><i class="ri-home-line"></i>&nbsp;</a>
                    <?php
                        $dataPathLocation = parse_url(base_url($_SERVER["REQUEST_URI"]), PHP_URL_PATH);
                        $dataPathLocation = array_values(array_filter(explode("/", $dataPathLocation)));
                        
                        if (count($dataPathLocation) > 0) {
                            echo " / ";
                            $formatPathSegment = function($segment) {
                                $segment = str_replace(['_', '-'], ' ', $segment);
                                return ucwords($segment); 
                            };
                        
                            $dataPathLocation = array_map($formatPathSegment, $dataPathLocation);
                            echo implode(" / ", $dataPathLocation);
                        }
                    ?>
                </div>
            </div>
            <?php
                if($view) {
                    $this->load->view($view);
                }
            ?>
        </div>
    </div>

    <script src="<?= base_url('assets/js/common.js?v='. strtotime(date("Y-m-d H:i:s"))) ?>"></script>
    <script src="<?= base_url('assets/js/main.js?v='. strtotime(date("Y-m-d H:i:s"))) ?>"></script>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
    
    <script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.2.7/pdfmake.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.2.7/vfs_fonts.js"></script>
    <script src="https://cdn.datatables.net/v/bs5/jszip-3.10.1/dt-2.1.2/b-3.1.0/b-colvis-3.1.0/b-html5-3.1.0/b-print-3.1.0/r-3.0.2/datatables.min.js"></script>

    <script>
        $(document).ready(() => {
            $("#modalAdd").on("hidden.bs.modal", () => {
                $("#frmAdd").trigger("reset");
            });

            $("#modalEdit").on("hidden.bs.modal", () => {
                $("#frmEdit").trigger("reset");
            });
        });
    </script>

</body>
</html>