<?php

    defined("BASEPATH") OR exit("Forbidden Access");

    class Index extends CI_Controller {

        public function __construct() {
            parent::__construct();
        }

        public function index() {
            $this->template->load("index", [
                "title" => "E-LEARNING"
            ]);
        }

    }