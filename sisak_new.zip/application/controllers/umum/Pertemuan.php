<?php

    defined("BASEPATH") OR exit("Forbidden Access");

    class Pertemuan extends CI_Controller {

        public function __construct() {
            parent::__construct();
        }

        public function index() {
            $this->template->load("umum/pertemuan", [
                "titleIcon" => "ri-group-line",
                "title" => "Tipe Pertemuan"
            ]);
        }

    }