<?php

    defined("BASEPATH") OR exit("Forbidden Access");

    class Materi extends CI_Controller {

        public function __construct() {
            parent::__construct();
        }

        public function index() {
            $this->template->load("umum/materi", [
                "titleIcon" => "ri-book-line",
                "title" => "Tipe Materi"
            ]);
        }

    }