<?php

    defined("BASEPATH") OR exit("Forbidden Access");

    class App_info extends CI_Controller {

        public function __construct() {
            parent::__construct();
        }

        public function index() {
            $this->template->load("umum/app_info", [
                "titleIcon" => "ri-information-2-line",
                "title" => "Informasi Aplikasi"
            ]);
        }

    }