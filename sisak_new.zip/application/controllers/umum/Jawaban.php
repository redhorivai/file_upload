<?php

    defined("BASEPATH") OR exit("Forbidden Access");

    class Jawaban extends CI_Controller {

        public function __construct() {
            parent::__construct();
        }

        public function index() {
            $this->template->load("umum/jawaban", [
                "titleIcon" => "ri-book-line",
                "title" => "Tipe Jawaban"
            ]);
        }

    }