<?php

    defined("BASEPATH") OR exit("Forbidden Access");

    class Kategori extends CI_Controller {

        public function __construct() {
            parent::__construct();
        }

        public function index() {
            $response = $this->curl->get($this->config->item('api_url') . 'master/get_user');

            $this->template->load("bank_soal/kategori", [
                "titleIcon" => "ri-bookmark-line",
                "title" => "Kategori - Bank Soal",
                "user" => $response,
            ]);
        }

    }