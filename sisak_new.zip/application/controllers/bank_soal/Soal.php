<?php

    defined("BASEPATH") OR exit("Forbidden Access");

    class Soal extends CI_Controller {

        public function __construct() {
            parent::__construct();
        }

        public function index() {
            $urls = [
                $this->config->item('api_url') . 'master/get_user',
                $this->config->item('api_url') . 'banksoal/kategori',
                $this->config->item('api_url') . 'general/tipe_jawaban',
            ];
        
            $responses = $this->curl->multi_get($urls);

            $this->template->load("bank_soal/soal", [
                "titleIcon" => "ri-book-open-line",
                "title" => "Daftar - Bank Soal",
                "user" => json_decode($responses[0]),
                "kategori" => json_decode($responses[1]),
                "tipe_jawaban" => json_decode($responses[2]),
            ]);
        }

    }