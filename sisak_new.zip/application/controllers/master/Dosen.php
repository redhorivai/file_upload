<?php

    defined("BASEPATH") OR exit("Forbidden Access");

    class Dosen extends CI_Controller {

        public function __construct() {
            parent::__construct();
        }

        public function index() {
            $this->template->load("master/dosen", [
                "titleIcon" => "ri-user-line",
                "title" => "Master Dosen"
            ]);
        }

    }