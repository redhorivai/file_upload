<?php

    defined("BASEPATH") OR exit("Forbidden Access");

    class Mahasiswa extends CI_Controller {

        public function __construct() {
            parent::__construct();
        }

        public function index() {
            $response = $this->curl->get($this->config->item('api_url') . 'master/get_dosen');

            $this->template->load("master/mahasiswa", [
                "titleIcon" => "ri-user-line",
                "title" => "Master Mahasiswa",
                "prodi" => $response
            ]);
        }

    }