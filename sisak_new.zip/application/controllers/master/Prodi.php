<?php

    defined("BASEPATH") OR exit("Forbidden Access");

    class Prodi extends CI_Controller {

        public function __construct() {
            parent::__construct();
        }

        public function index() {
            $this->template->load("master/prodi", [
                "titleIcon" => "ri-graduation-cap-line",
                "title" => "Master Prodi"
            ]);
        }

    }