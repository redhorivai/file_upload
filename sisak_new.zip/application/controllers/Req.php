<?php

    defined("BASEPATH") OR exit("Forbidden Access");

    class Req extends CI_Controller {

        private $apiURL;

        public function __construct() {
            parent::__construct();
            
            header("Content-Type: Application/JSON");
            header("Access-Control-Allow-Origin: *");
            
            $this->apiURL = $this->config->item('api_url');
        }

        /**
         * Helper
         */
        public function apiUrl($path = false) {
            return $this->apiURL . ($path ? $path : '');
        }

        /**
         * General
         */
        public function getUmumAppInfo() {
            $response = $this->curl->get($this->apiUrl('configuration/get'));
            Helper::outputJson($response);
        }
        
        public function getUmumProdi() {
            $response = $this->curl->get($this->apiUrl('general/tipe_prodi'));
            Helper::outputJson($response);
        }

        public function getUmumJawaban() {
            $response = $this->curl->get($this->apiUrl('general/tipe_jawaban'));
            Helper::outputJson($response);
        }
        
        public function getUmumMateri() {
            $response = $this->curl->get($this->apiUrl('general/tipe_materi'));
            Helper::outputJson($response);
        }
        
        public function getUmumPertemuan() {
            $response = $this->curl->get($this->apiUrl('general/tipe_pertemuan'));
            Helper::outputJson($response);
        }
        
        public function getUmumUjian() {
            $response = $this->curl->get($this->apiUrl('general/tipe_ujian'));
            Helper::outputJson($response);
        }
        
        public function getUmumSegmen() {
            $response = $this->curl->get($this->apiUrl('general/tipe_segmen'));
            Helper::outputJson($response);
        }
        
        public function getUmumRole() {
            $response = $this->curl->get($this->apiUrl('general/roles'));
            Helper::outputJson($response);
        }

        /**
         * Master
         */
        public function getMasterUser() {
            $response = $this->curl->get($this->apiUrl('master/get_user'));
            Helper::outputJson($response);
        }

        public function insertMasterUser() {
            $input = $this->input->post();

            $data = [
                "nama" => $input["nama"],
                "email" => $input["email"],
                "username" => $input["username"],
                "password" => $input["password"],
                "active" => $input["status"],
                "roles" => "admin",
            ];

            $response = $this->curl->post($this->apiUrl('master/user/insert'), $data);
            Helper::outputJson($response);
        }

        public function updateMasterUser() {
            $input = $this->input->post();
            
            $data = [
                "name" => $input["nama"],
                "email" => $input["email"],
                "old_email" => $input["old_email"],
                "username" => $input["username"],
                "password" => $input["password"],
                "active" => $input["status"],
            ];

            $response = $this->curl->put($this->apiUrl('master/user/update/'. $input["id"]), $data);
            Helper::outputJson($response);
        }

        public function deleteMasterUser($id) {
            $response = $this->curl->delete($this->apiUrl('master/user/delete/'. $id));
            Helper::outputJson($response);
        }

        public function getMasterMahasiswa() {
            $response = $this->curl->get($this->apiUrl('master/get_mahasiswa'));
            Helper::outputJson($response);
        }

        public function insertMasterMahasiswa() {
            $input = $this->input->post();

            $data = [
                "username" => $input["username"],
                "nama" => $input["nama"],
                "email" => $input["email"],
                "password" => $input["password"],
                "active" => $input["status"],
                "prodi_id" => $input["prodi_id"],
                "tanggal_lahir" => $input["tanggal_lahir"],
                "tahun_masuk" => $input["tahun_masuk"],
                "kelas" => $input["kelas"]
            ];

            $response = $this->curl->post($this->apiUrl('master/mahasiswa/insert'), $data);
            Helper::outputJson($response);
        }

        public function updateMasterMahasiswa() {
            $input = $this->input->post();
            
            $data = [
                "username" => $input["username"],
                "name" => $input["nama"],
                "email" => $input["email"],
                "old_email" => $input["old_email"],
                "password" => $input["password"],
                "active" => $input["status"],
                "prodi_id" => $input["prodi_id"],
                "tanggal_lahir" => $input["tanggal_lahir"],
                "tahun_masuk" => $input["tahun_masuk"],
                "kelas" => $input["kelas"]
            ];

            $response = $this->curl->put($this->apiUrl('master/mahasiswa/update/'. $input["id"]), $data);
            Helper::outputJson($response);
        }

        public function deleteMasterMahasiswa($id) {
            $response = $this->curl->delete($this->apiUrl('master/mahasiswa/delete/'. $id));
            Helper::outputJson($response);
        }

        public function getmasterDosen() {
            $response = $this->curl->get($this->apiUrl('master/get_dosen'));
            Helper::outputJson($response);
        }

        public function insertMasterDosen() {
            $input = $this->input->post();

            $data = [
                "username" => $input["username"],
                "nama" => $input["nama"],
                "email" => $input["email"],
                "password" => $input["password"],
                "active" => $input["status"]
            ];

            $response = $this->curl->post($this->apiUrl('master/dosen/insert'), $data);
            Helper::outputJson($response);
        }

        public function updateMasterDosen() {
            $input = $this->input->post();
            
            $data = [
                "username" => $input["username"],
                "name" => $input["nama"],
                "email" => $input["email"],
                "old_email" => $input["old_email"],
                "password" => $input["password"],
                "active" => $input["status"]
            ];

            $response = $this->curl->put($this->apiUrl('master/dosen/update/'. $input["id"]), $data);
            Helper::outputJson($response);
        }

        public function deleteMasterDosen($id) {
            $response = $this->curl->delete($this->apiUrl('master/dosen/delete/'. $id));
            Helper::outputJson($response);
        }

        public function getMasterProdi() {
            $response = $this->curl->get($this->apiUrl('master/get_prodi'));
            Helper::outputJson($response);
        }

        /**
         * Bank Soal
         */
        public function getBankSoalKategori() {
            $response = $this->curl->get($this->apiUrl('banksoal/kategori'));
            Helper::outputJson($response);
        }

        public function getBankSoalSoal() {
            $response = $this->curl->get($this->apiUrl('banksoal/list'));
            Helper::outputJson($response);
        }

        public function insertBankSoalKategori() {
            $input = $this->input->post();

            $response = $this->curl->post($this->apiURL('banksoal/kategori/insert'), [
                "nama" => $input["nama"],
                "keterangan" => $input["keterangan"],
                "creator_id" => 2
            ]);
            Helper::outputJson($response);
        }

        public function updateBankSoalKategori() {
            $input = $this->input->post();

            $response = $this->curl->put($this->apiURL('banksoal/kategori/update/'. $input["id"]), [
                "nama" => $input["nama"],
                "keterangan" => $input["keterangan"],
                "creator_id" => 2
            ]);
            Helper::outputJson($response);
        }

        public function deleteBankSoalKategori($id) {
            $response = $this->curl->delete($this->apiURL('banksoal/kategori/delete/'. $id));
            Helper::outputJson($response);
        }

        public function insertBankSoal() {
            $input = $this->input->post();

            if($input["tipe_jawaban"] === "0") {
                $pilihan = $input["pilihan"];
                $jawaban = $input["jawaban"];
            } else if($input["tipe_jawaban"] === "1") {
                $pilihan = "";
                $jawaban = $input["jawaban"];
            } else if($input["tipe_jawaban"] === "2") {
                $pilihan = "";
                $jawaban = "";
            } else if($input["tipe_jawaban"] === "3") {
                $jawaban = $input["jawaban"];
                $pilihan = "";
            } else {
                $pilihan = "";
                $jawaban = "";
            }

            $response = $this->curl->post($this->apiURL('banksoal/soal/insert'), [
                "creator_id" => $input["creator_id"],
                "kategori_id" => $input["kategori_id"],
                "pertanyaan" => $input["pertanyaan"],
                "tipe_jawaban" => $input["tipe_jawaban"],
                "pilihan" => $pilihan,
                "jawaban" => $jawaban,
            ]);
            Helper::outputJson($response);
        }

        public function updateBankSoal() {
            $input = $this->input->post();

            if($input["tipe_jawaban"] === "0") {
                $pilihan = $input["pilihan"];
                $jawaban = $input["jawaban"];
            } else if($input["tipe_jawaban"] === "1") {
                $pilihan = "";
                $jawaban = $input["jawaban"];
            } else if($input["tipe_jawaban"] === "2") {
                $pilihan = "";
                $jawaban = "";
            } else if($input["tipe_jawaban"] === "3") {
                $jawaban = $input["jawaban"];
                $pilihan = "";
            } else {
                $pilihan = "";
                $jawaban = "";
            }

            $response = $this->curl->put($this->apiURL('banksoal/soal/update/'. $input["id"]), [
                "creator_id" => $input["creator_id"],
                "kategori_id" => $input["kategori_id"],
                "pertanyaan" => $input["pertanyaan"],
                "tipe_jawaban" => $input["tipe_jawaban"],
                "pilihan" => $pilihan,
                "jawaban" => $jawaban,
            ]);
            Helper::outputJson($response);
        }

        public function deleteBankSoal($id) {
            $response = $this->curl->delete($this->apiURL('banksoal/soal/delete/'. $id));
            Helper::outputJson($response);
        }

        /**
         * RPS
         */
        public function getRps() {
            $response = $this->curl->get($this->apiUrl('rps/list'));
            Helper::outputJson($response);
        }

        public function insertRps() {
            $input = $this->input->post();

            $response = $this->curl->post($this->apiURL('rps/insert'), [
                "creator_id" => $input["creator_id"],
                "prodi_id" => $input["prodi_id"],
                "matkul" => $input["matkul"],
                "kode_matkul" => $input["kode_matkul"],
                "semester" => $input["semester"],
                "sks" => $input["sks"],
                "pertemuan" => $input["pertemuan"],
                "referensi" => null,
                "dosen" => (isset($input["dosen"]) ? $input["dosen"] : []),
                "publish" => $input["publish"],
                "approved" => $input["approved"],
                "approved_by" => $input["approved_by"],
            ]);
            Helper::outputJson($response);
        }

        public function updateRps() {
            $input = $this->input->post();

            $response = $this->curl->put($this->apiURL('rps/update/'. $input["id"]), [
                "creator_id" => $input["creator_id"],
                "prodi_id" => $input["prodi_id"],
                "matkul" => $input["matkul"],
                "kode_matkul" => $input["kode_matkul"],
                "semester" => $input["semester"],
                "sks" => $input["sks"],
                "pertemuan" => $input["pertemuan"],
                "referensi" => null,
                "dosen" => (isset($input["dosen"]) ? $input["dosen"] : []),
                "publish" => $input["publish"],
                "approved" => $input["approved"],
                "approved_by" => $input["approved_by"],
            ]);
            Helper::outputJson($response);
        }

        public function deleteRps($id) {
            $input = $this->input->post();

            $response = $this->curl->delete($this->apiURL('rps/delete/'. $id));
            Helper::outputJson($response);
        }

    }