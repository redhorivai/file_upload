<?php

    defined("BASEPATH") OR exit("Forbidden Access");

    class Rps extends CI_Controller {

        public function __construct() {
            parent::__construct();
        }

        public function index() {
            $urls = [
                $this->config->item('api_url') . 'master/get_dosen',
                $this->config->item('api_url') . 'master/get_prodi',
                $this->config->item('api_url') . 'master/get_user',
            ];
        
            $responses = $this->curl->multi_get($urls);

            $this->template->load("rps/rps", [
                "titleIcon" => "ri-book-open-line",
                "title" => "Daftar RPS",
                "dosen" => json_decode($responses[0]),
                "prodi" => json_decode($responses[1]),
                "user" => json_decode($responses[2]),
            ]);
        }

        public function detail($id) {
            $urls = [
                $this->config->item('api_url') . 'master/get_dosen',
                $this->config->item('api_url') . 'master/get_prodi',
                $this->config->item('api_url') . 'master/get_user',
            ];
        
            $responses = $this->curl->multi_get($urls);

            $this->template->load("rps/detail", [
                "titleIcon" => "ri-book-open-line",
                "title" => "RPS Detail",
                "dosen" => json_decode($responses[0]),
                "prodi" => json_decode($responses[1]),
                "user" => json_decode($responses[2]),
            ]);
        }

    }