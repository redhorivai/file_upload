<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

/**
 * cURL Library
 *
 * Provides methods to perform cURL requests.
 */
class Curl {

    protected $ci;
    protected $ch;

    public function __construct()
    {
        // Get CodeIgniter instance
        $this->ci =& get_instance();
        
        // Initialize cURL session
        $this->ch = curl_init();
    }

    public function multi_get($urls, $headers = array())
    {
        $multiCurl = [];
        $results = [];
        $mh = curl_multi_init();

        foreach ($urls as $i => $url) {
            $multiCurl[$i] = curl_init();
            curl_setopt($multiCurl[$i], CURLOPT_URL, $url);
            curl_setopt($multiCurl[$i], CURLOPT_RETURNTRANSFER, true);
            curl_setopt($multiCurl[$i], CURLOPT_HTTPGET, true);
            if (!empty($headers)) {
                curl_setopt($multiCurl[$i], CURLOPT_HTTPHEADER, $headers);
            }
            curl_multi_add_handle($mh, $multiCurl[$i]);
        }

        $index = null;
        do {
            curl_multi_exec($mh, $index);
        } while ($index > 0);

        foreach ($multiCurl as $i => $ch) {
            $results[$i] = curl_multi_getcontent($ch);
            curl_multi_remove_handle($mh, $ch);
            curl_close($ch);
        }

        curl_multi_close($mh);
        return $results;
    }

    /**
     * Perform a GET request using cURL
     *
     * @param string $url The URL to fetch
     * @param array $headers (Optional) Array of headers to include in the request
     * @return string Response body
     */
    public function get($url, $headers = array())
    {
        curl_setopt($this->ch, CURLOPT_URL, $url);
        curl_setopt($this->ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($this->ch, CURLOPT_HTTPGET, true);

        if (!empty($headers)) {
            curl_setopt($this->ch, CURLOPT_HTTPHEADER, $headers);
        }

        $response = curl_exec($this->ch);
        return $this->_handle_response($response);
    }

    /**
     * Perform a POST request using cURL
     *
     * @param string $url The URL to post to
     * @param array $data Array of POST data
     * @param array $headers (Optional) Array of headers to include in the request
     * @return string Response body
     */
    public function post($url, $data = array(), $headers = array())
    {
        curl_setopt($this->ch, CURLOPT_URL, $url);
        curl_setopt($this->ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($this->ch, CURLOPT_POST, true);
        curl_setopt($this->ch, CURLOPT_POSTFIELDS, http_build_query($data));

        if (!empty($headers)) {
            curl_setopt($this->ch, CURLOPT_HTTPHEADER, $headers);
        }

        $response = curl_exec($this->ch);
        return $this->_handle_response($response);
    }

    /**
     * Perform a PUT request using cURL
     *
     * @param string $url The URL to put to
     * @param array $data Array of PUT data
     * @param array $headers (Optional) Array of headers to include in the request
     * @return string Response body
     */
    public function put($url, $data = array(), $headers = array())
    {
        curl_setopt($this->ch, CURLOPT_URL, $url);
        curl_setopt($this->ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($this->ch, CURLOPT_CUSTOMREQUEST, 'PUT');
        curl_setopt($this->ch, CURLOPT_POSTFIELDS, http_build_query($data));

        if (!empty($headers)) {
            curl_setopt($this->ch, CURLOPT_HTTPHEADER, $headers);
        }

        $response = curl_exec($this->ch);
        return $this->_handle_response($response);
    }

    /**
     * Perform a DELETE request using cURL
     *
     * @param string $url The URL to delete
     * @param array $data (Optional) Array of DELETE data to include in the body
     * @param array $headers (Optional) Array of headers to include in the request
     * @return string Response body
     */
    public function delete($url, $data = array(), $headers = array())
    {
        curl_setopt($this->ch, CURLOPT_URL, $url);
        curl_setopt($this->ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($this->ch, CURLOPT_CUSTOMREQUEST, 'DELETE');

        if (!empty($data)) {
            curl_setopt($this->ch, CURLOPT_POSTFIELDS, http_build_query($data));
        }

        if (!empty($headers)) {
            curl_setopt($this->ch, CURLOPT_HTTPHEADER, $headers);
        }

        $response = curl_exec($this->ch);
        return $this->_handle_response($response);
    }

    /**
     * Handle cURL response
     *
     * @param mixed $response The raw response from cURL
     * @return string Response body or error message
     */
    private function _handle_response($response)
    {
        if (curl_errno($this->ch)) {
            $error_msg = curl_error($this->ch);
            curl_close($this->ch);
            return "cURL Error: $error_msg";
        }

        curl_close($this->ch);
        return json_decode($response);
    }
}
