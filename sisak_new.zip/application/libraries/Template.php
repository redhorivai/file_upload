<?php

    defined("BASEPATH") OR die("Forbidden Access");

    class Template {

        private $CI;
        
        public function __construct() {
            $this->CI =& get_instance();
        }

        public function load($view = false, $data = []) {
            $defaultData = [
                "view" => ($view ? $view : false),
                "baseTitle" => "POLTEKPAR PALEMBANG"
            ];
            
            $this->CI->load->view("template/index", array_merge($defaultData, $data));
        }

    }