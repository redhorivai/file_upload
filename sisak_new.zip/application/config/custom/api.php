<?php

    defined("BASEPATH") OR exit("Forbidden Access");

    $config["api_url"] = "http://elearning.poltekpar_palembang.ac.id/api/";