const Common = {

    generateDTStatus: false,

    mixinTA : (custom = false) =>{
        if(custom){
            return Swal.mixin(custom);
        } else {
            return Swal.mixin({
                confirmButtonText: "Tutup",
                confirmButtonColor: "var(--bs-danger)"
            });
        }
    },
    
    ajaxErrorMsg : (title) => {
        return Common.thisAlert(title, "Gagal memproses permintaan<br />Kesalahan sistem (klien)", "error");
    },

    ajaxErrorUnd : (title) => {
        return Common.thisAlert(title, "Undefined Status Result", "error");
    },
    
    thisAlert : (title = false, body, type = false, Mixin = false) => {
        if (Mixin) {
            return Mixin.fire({
                title: title || false,
                html: body || false,
                icon: type || false
            });
        } else {
            let buttonColor = (typeIcon) => {
                switch(typeIcon){
                    case "success" : 
                        return `var(--bs-success)`;
                    case "error" : 
                        return `var(--bs-danger)`;
                    case "warning" : 
                        return `var(--bs-warning)`;
                    case "info" : 
                        return `var(--bs-cyan)`;
                    case "question" : 
                        return `var(--bs-primary-border-subtle)`;
                    default : 
                        return `var(--bs-secondary)`;
                }
            };

            return Swal.fire({
                title: title || false,
                html: body || false,
                icon: type || false,
                confirmButtonText: "Ok",
                confirmButtonColor: buttonColor(type)
            });
        }
    },

    showHide : (input, toggle) => {
        if($(input).prop("type") == "password"){
            $(toggle).html(`<i class="ri-eye-line"></i>`);
            $(input).prop("type", "text");
        } else {
            $(toggle).html(`<i class="ri-eye-off-line"></i>`);
            $(input).prop("type", "password");
        }
    },

    htmlEntities : (str) => {
        return String(str).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
    },

    payloadChecker : (data) => {
        var status = true;
        var message = "";

        $.each(data.reverse(), (k, v) => {
            if (v.value == "" || v.value == null) {
                status = false;
                message = v.message;
            }
        });

        return {
            status: status,
            message: message,
            data: data
        };
    },

    uniqId : (prefix = "", random = false) => {
        const sec = Date.now() * 1000 + Math.random() * 1000;
        const id = sec.toString(16).replace(/\./g, "").padEnd(14, "0");
        return `${prefix}${id}${random ? `.${Math.trunc(Math.random() * 100000000)}`:""}`;
    },

    numberFormat : (number, id = false) => {
        var filtered_number = number.replace(/[^0-9]/gi, '');
        var length = filtered_number.length;
        var breakpoint = 1;
        var formated_number = '';
    
        for(i = 1; i <= length; i++){
            if(breakpoint > 3){
                breakpoint = 1;
                formated_number = '.' + formated_number;
            }
            var next_letter = i + 1;
            formated_number = filtered_number.substring(length - i, length - (i - 1)) + formated_number; 
    
            breakpoint++;
        }

        if(id){
            $("#"+ id).val("Rp "+ formated_number);
        } else {
            return formated_number;
        }
    },

    nl2br : (str) => {
        return str.replace(/\n/g, "<br>");
    },
    
    urlencode : (str) => {
        return encodeURIComponent(str)
            .replace(/!/g, '%21')
            .replace(/'/g, '%27')
            .replace(/\(/g, '%28')
            .replace(/\)/g, '%29')
            .replace(/\*/g, '%2A')
            .replace(/%20/g, '+');
    },
    
    urldecode : (str) => {
        return decodeURIComponent(str.replace(/\+/g, ' '));
    },

    undefined : (value) => {
        if(typeof value !== "undefined"){
            return true;
        } else {
            return false;
        }
    },

    ajaxReq: (ajax, callbackSuccess, callbackFailed) => {
        const ajaxOpt = {
            url: ajax.url,
            type: ajax.type || 'GET',
            dataType: "JSON",
            async: ajax.async !== undefined ? ajax.async : true,
            cache: ajax.cache !== undefined ? ajax.cache : false,
            beforeSend: ajax.beforeSend || function () {},
            success: function (res) {
                callbackSuccess(res);
            },
            error: function (jqXHR) {
                callbackFailed(jqXHR);
            }
        };
    
        if (ajax.media) {
            ajaxOpt.contentType = false;
            ajaxOpt.processData = false;
        }
    
        if (ajax.data) {
            ajaxOpt.data = ajax.data;
        }
    
        if (ajax.headers) {
            ajaxOpt.headers = ajax.headers;
        }
    
        $.ajax(ajaxOpt);
    },

    ajaxReqOld : (options, callbackSuccess, callbackFailed) => {
        const { alertTitle = "Error", payload = false, ajax = {}} = options;
        const ajaxOpt = {}
        let beforeSend = "";
        
        if(payload){
            const payloadChecker = Common.payloadChecker(payload);
            if(!payloadChecker.status){
                Common.thisAlert(alertTitle, payloadChecker.message, "error");
                return;
            }
        }

        if(ajax.media){
            ajaxOpt.contentType = false;
            ajaxOpt.processData = false;
        }

        if(ajax.data){
            ajaxOpt.data = ajax.data;
        }

        if(ajax.beforeSend){
            beforeSend = ajax.beforeSend;
        } else {
            beforeSend = () => {}
        }

        $.ajaxSetup(ajaxOpt);

        $.ajax({
            url : `${ajax.url}`,
            type : ajax.type,
            dataType : "JSON",
            beforeSend: beforeSend,
            success : (res) => {
                callbackSuccess(res);
            },
            error : (jqXHR) => {
                if(callbackFailed){
                    callbackFailed(jqXHR);
                }
            }
        });
    },

    datatable : (opt) => {
        const { selector, url, columns, order = [[0, 'desc']], customButtons = [], exportButtons = false } = opt;
        
        const datatableOpt = {};

        datatableOpt.processing     = true;
        datatableOpt.serverSide     = true;
        datatableOpt.columns        = columns;
        datatableOpt.order          = order;
        datatableOpt.language       = {
            lengthMenu: "_MENU_ row",
            search: "<i class='ri-search-line'></i>"
        };
        datatableOpt.ajax           = {
            url: `${BASEURL + url}`,
            type: "POST"
        };

        let customButton = customButtons;
        if(customButton && customButton.length > 0){
            customButton = {
                buttons: customButtons
            }
        }

        let exportButton = exportButtons;
        if(exportButton){
            exportButton = {
                buttons: [
                    {
                        extend: "copy",
                        text: "<i class='ri-file-copy-line'></i>&nbsp; Copy",
                        attr: {
                            class: "btn btn-secondary mb-2"
                        }
                    },
                    {
                        extend: "csv",
                        text: "<i class='ri-file-excel-2-line'></i>&nbsp; CSV",
                        attr: {
                            class: "btn btn-success mb-2"
                        }
                    },
                    {
                        extend: "excel",
                        text: "<i class='ri-file-excel-2-line'></i>&nbsp; Excel",
                        attr: {
                            class: "btn btn-success mb-2"
                        }
                    },
                    {
                        extend: "pdf",
                        text: "<i class='ri-file-pdf-2-line'></i>&nbsp; PDF",
                        attr: {
                            class: "btn btn-danger mb-2"
                        }
                    },
                    {
                        extend: "print",
                        text: "<i class='ri-file-excel-2-line'></i>&nbsp; Print",
                        attr: {
                            class: "btn btn-outline-dark mb-2"
                        }
                    },
                ]
            };
        }

        datatableOpt.layout = {
            top2Start: exportButton,
            top2End: customButton
        }

        datatableOpt.paging = true;
        datatableOpt.processing = true,
        datatableOpt.scrollY = 370

        let datatable = $(selector).DataTable(datatableOpt);

        $(document).on('click', `.reloadTable`, function() {
            datatable.ajax.reload();
        });

        $(".dt-container.dt-bootstrap5").children().eq(0).removeClass("mt-2"); 

        return datatable;
    },

    generateDatatable: (el, options = { "order": [] }) => {
        $(el).DataTable(options);
        Common.generateDTStatus = true;
    },

    resetDatatable: (el, setFunc = false) => {
        if ($.fn.DataTable.isDataTable(el)) {
            $(el).DataTable().destroy();
        }
        
        Common.generateDTStatus = false;
        if(setFunc) {
            setFunc();
        } else {
            Common.generateDatatable(el);
        }
    },

    renderToTable: (el, data, callback, withDT = true, DTopt = { "order": [] }) => {
        let list = "";

        $.each(data, (i, v) => {
            list += callback(i, v);
        });

        $(`${el} tbody`).html(list);
        if(withDT) {
            Common.generateDatatable(el, DTopt);
        }
    },

    htmlentities: (str) => {
        return str.replace(/[\u00A0-\u9999<>&]/gim, function(i) {
            return '&#' + i.charCodeAt(0) + ';';
        });
    },

    mb_strimwidth: (str, start, width, trimmarker = '') => {
        if (start < 0) {
            start = 0;
        }
        if (width <= 0) {
            return '';
        }
    
        let trimmedStr = str.substring(start, start + width);
    
        // Check if we need to add the trim marker
        if (str.length > start + width) {
            trimmedStr += trimmarker;
        }
    
        return trimmedStr;
    },

    formatDate: (inputDate, type = false) => {
        const date = new Date(inputDate);
        const pad = (num) => num.toString().padStart(2, '0');
        const year = date.getFullYear();
        const month = pad(date.getMonth() + 1);
        const day = pad(date.getDate());
        const hours = pad(date.getHours());
        const minutes = pad(date.getMinutes());
        const seconds = pad(date.getSeconds());
        if(type) {
            return `${year}-${month}-${day}`;
        }
        
        return `${year}-${month}-${day} ${hours}:${minutes}:${seconds}`;
    }

};